package finalprojtask1;
import java.util.UUID;

public final class MyUUID implements Comparable{
    String key;
    UUID uuid;
    //add final to this data members


    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
