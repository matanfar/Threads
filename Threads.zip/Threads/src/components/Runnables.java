package components;

public class Runnables {
    public static void main(String[] args) {
        Runnable r1 = new Runnable() {
            @Override
            public void run() {
                System.out.println(Thread.currentThread().getName() + "running, id: " + Thread.currentThread().getId());
            }
        };

        Runnable r2 = ()->{
            StringBuilder dynamicString = new StringBuilder("ABCDEFGHIJK");
            System.out.println(dynamicString.reverse().toString());
        };

        Runnable r3 = ()->{
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };

        System.out.println("Hello from " + Thread.currentThread().getName() + "!");
        Thread t1 = new Thread(r1);
        t1.start();
    }
}
